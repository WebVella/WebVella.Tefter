﻿Our flag icons are provided with big thanks from 
https://github.com/lipis/flag-icons/ 
We use the 4x3 version.